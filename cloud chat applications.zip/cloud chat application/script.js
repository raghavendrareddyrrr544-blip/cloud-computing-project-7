import { initializeApp } from
    "https://www.gstatic.com/firebasejs/12.1.0/firebase-app.js";

import {
    getDatabase,
    ref,
    push,
    onChildAdded
} from
    "https://www.gstatic.com/firebasejs/12.1.0/firebase-database.js";

const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_PROJECT.firebaseapp.com",
    databaseURL: "YOUR_DATABASE_URL",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_PROJECT.appspot.com",
    messagingSenderId: "YOUR_SENDER_ID",
    appId: "YOUR_APP_ID"
};

const app = initializeApp(firebaseConfig);
const database = getDatabase(app);

const messagesRef = ref(database, "messages");

window.sendMessage = function () {

    const username =
        document.getElementById("username").value.trim();

    const message =
        document.getElementById("message").value.trim();

    if (username === "" || message === "") {
        alert("Please enter your name and message.");
        return;
    }

    push(messagesRef, {
        username: username,
        message: message,
        time: new Date().toLocaleTimeString()
    });

    document.getElementById("message").value = "";
};

onChildAdded(messagesRef, (snapshot) => {

    const data = snapshot.val();

    const messageDiv = document.createElement("div");
    messageDiv.className = "message";

    messageDiv.innerHTML = `
        <strong>${data.username}</strong><br>
        ${data.message}
        <small> (${data.time})</small>
    `;

    document.getElementById("messages")
        .appendChild(messageDiv);

    const messages =
        document.getElementById("messages");

    messages.scrollTop = messages.scrollHeight;
});